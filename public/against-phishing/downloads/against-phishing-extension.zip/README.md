# Against Phishing

Extension Chrome / Firefox qui repère les faux sites imitant les banques, services publics et marques françaises (Ameli, impots.gouv, ANTAI, La Poste, Chronopost, CPF, banques, opérateurs…), **sans attendre qu'ils soient listés** par Google Safe Browsing.

## Ce qu'elle détecte

- **Sosies de domaines** : fautes de frappe (`chronoposte.fr`), caractères trompeurs (`paypa1.com`, `pаypal.com` avec un « а » cyrillique, `rnicrosoft.com`), même nom avec une autre extension (`ameli.com`).
- **Marque dans l'adresse** : `ameli-remboursement.fr`, `laposte.colis-livraison.xyz`.
- **Indices de contexte** : mots typiques d'arnaque (colis, remboursement, amende…), extensions à risque (.xyz, .top…), hébergeurs gratuits, adresses IP brutes, punycode.
- **Âge du domaine** via RDAP (successeur du WHOIS) : un « site Ameli » créé il y a 3 jours est un signal fort.

Résultat : un badge sur l'icône (✓ officiel, ? suspect, ! dangereux) et un **écran d'alerte plein écran** qui bloque la page (plus de clic, de défilement ni de saisie possible) :

- dès l'ouverture d'un site dangereux ;
- sur un site suspect, au moment de cliquer dans un champ mot de passe ou carte bancaire.

Le bouton principal fait quitter le site. Pour passer outre, il faut ouvrir « Je sais ce que je fais » et cocher une case de confirmation.

## Appli mobile « Vérifier un lien »

Le dossier `app/` est une appli web installable (PWA) pour iPhone et Android, qui réutilise le même moteur d'analyse. On y colle un lien ou un SMS entier ; sur Android, une fois installée, elle apparaît aussi dans le menu « Partager » des SMS et e-mails. Le verdict s'affiche en plein écran, avec un bouton pour signaler au 33700.

Sur mobile, une appli ne peut pas surveiller la navigation des autres applis : la protection automatique passe par l'extension, compatible Firefox Android une fois publiée sur addons.mozilla.org (Firefox Android n'installe que des extensions signées).

## Site et déploiement

`site/` contient la page d'accueil, qui intègre un vérificateur de lien. `scripts/build-site.sh` assemble dans `_site/` la page d'accueil, l'appli (`/app/`) et l'extension à télécharger (`/downloads/against-phishing-extension.zip`).

Le workflow `.github/workflows/pages.yml` lance les tests puis déploie `_site/` sur GitHub Pages à chaque push sur `main`. À activer une fois : Settings → Pages → Source : **GitHub Actions**.

## Vie privée

L'analyse se fait entièrement dans le navigateur. La seule requête externe est la recherche de date de création du domaine sur `rdap.org`, qui ne reçoit que le **nom de domaine** (jamais l'URL complète), et uniquement si la page est déjà suspecte ou demande un mot de passe / une carte. Les réponses sont mises en cache 7 jours.

## Installer en local

- **Chrome / Edge / Brave** : `chrome://extensions` → activer le mode développeur → « Charger l'extension non empaquetée » → choisir ce dossier.
- **Firefox (121+)** : `about:debugging#/runtime/this-firefox` → « Charger un module complémentaire temporaire » → choisir `manifest.json`.

## Développer

```
npm test
```

Les marques surveillées sont dans `src/lib/brands.js`, les règles et leurs poids dans `src/lib/analyzer.js` (≥ 30 : suspect, ≥ 60 : dangereux).
