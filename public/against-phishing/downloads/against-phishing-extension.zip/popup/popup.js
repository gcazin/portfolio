const api = globalThis.browser ?? globalThis.chrome;

const COPY = {
    official: { title: 'Site officiel', summary: (verdict) => `Ce domaine appartient bien à ${verdict.brand}.` },
    trusted: { title: 'Site de confiance', summary: () => 'Vous avez indiqué faire confiance à ce site.' },
    neutral: { title: 'Aucun signal suspect', summary: () => 'Rien n\'indique une imitation. Restez tout de même vigilant si on vous demande de payer ou de vous connecter.' },
    warning: { title: 'Site suspect', summary: () => 'Plusieurs indices laissent penser que ce site pourrait être frauduleux.' },
    danger: { title: 'Faux site probable', summary: (verdict) => verdict.brand ? `Ce site semble imiter ${verdict.brand}. N'y saisissez aucune information.` : 'Ce site présente de forts signes d\'arnaque. N\'y saisissez aucune information.' },
    ignored: { title: 'Page non analysée', summary: () => 'Seules les pages web (http et https) sont analysées.' },
};

const app = document.getElementById('app');

function formatAge(days) {
    if (days < 1) {
        return 'moins d\'un jour';
    }
    if (days < 60) {
        return `${Math.floor(days)} jours`;
    }
    if (days < 730) {
        return `${Math.floor(days / 30)} mois`;
    }
    return `${Math.floor(days / 365)} ans`;
}

function render(verdict, tabId) {
    const level = verdict?.level ?? 'ignored';
    const copy = COPY[level];
    app.dataset.level = level;
    document.getElementById('title').textContent = copy.title;
    document.getElementById('host').textContent = verdict?.hostname ?? '';
    document.getElementById('summary').textContent = copy.summary(verdict ?? {});

    const reasons = document.getElementById('reasons');
    reasons.replaceChildren(...(verdict?.reasons ?? []).map((reason) => {
        const item = document.createElement('li');
        item.textContent = reason.message;
        return item;
    }));

    const age = document.getElementById('age');
    age.hidden = typeof verdict?.domainAgeDays !== 'number';
    if (!age.hidden) {
        age.textContent = `Nom de domaine enregistré il y a ${formatAge(verdict.domainAgeDays)}.`;
    }

    const trust = document.getElementById('trust');
    const untrust = document.getElementById('untrust');
    trust.hidden = !['neutral', 'warning', 'danger'].includes(level);
    untrust.hidden = level !== 'trusted';
    trust.onclick = async () => render(await api.runtime.sendMessage({ type: 'trust-domain', domain: verdict.domain, tabId }), tabId);
    untrust.onclick = async () => render(await api.runtime.sendMessage({ type: 'untrust-domain', domain: verdict.domain, tabId }), tabId);
}

const [tab] = await api.tabs.query({ active: true, currentWindow: true });
render(await api.runtime.sendMessage({ type: 'tab-verdict', tabId: tab.id }), tab.id);
