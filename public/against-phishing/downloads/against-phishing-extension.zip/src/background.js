import { analyzeUrl, Level } from './lib/analyzer.js';
import { domainAgeDays } from './lib/rdap.js';

const api = globalThis.browser ?? globalThis.chrome;

const BADGES = {
    [Level.Official]: { text: '✓', color: '#1b7f3b', title: 'Site officiel reconnu' },
    [Level.Trusted]: { text: '✓', color: '#4a5568', title: 'Site marqué comme fiable par vous' },
    [Level.Warning]: { text: '?', color: '#d97706', title: 'Site suspect : restez prudent' },
    [Level.Danger]: { text: '!', color: '#c81e1e', title: 'Faux site probable' },
};

async function getTrustedDomains() {
    const { trustedDomains = [] } = await api.storage.local.get('trustedDomains');
    return trustedDomains;
}

/**
 * The registry lookup only runs when something is already off, or when the page asks for
 * a password or card number: ordinary browsing never leaves the browser.
 */
function needsAgeLookup(verdict, hasSensitiveForm) {
    const analysable = [Level.Neutral, Level.Warning, Level.Danger].includes(verdict.level);
    return analysable && (verdict.score > 0 || hasSensitiveForm);
}

async function verdictFor(url, { hasSensitiveForm = false } = {}) {
    const trustedDomains = await getTrustedDomains();
    const verdict = analyzeUrl(url, { trustedDomains });
    if (!needsAgeLookup(verdict, hasSensitiveForm)) {
        return { ...verdict, domainAgeDays: null };
    }
    const ageDays = await domainAgeDays(verdict.domain, api.storage.local);
    return { ...analyzeUrl(url, { trustedDomains, domainAgeDays: ageDays }), domainAgeDays: ageDays };
}

async function showBadge(tabId, verdict) {
    const badge = BADGES[verdict.level];
    await api.action.setBadgeText({ tabId, text: badge?.text ?? '' });
    if (badge) {
        await api.action.setBadgeBackgroundColor({ tabId, color: badge.color });
    }
    await api.action.setTitle({ tabId, title: badge ? `Against Phishing — ${badge.title}` : 'Against Phishing' });
}

async function refreshTab(tabId, url, options) {
    const verdict = await verdictFor(url, options);
    await showBadge(tabId, verdict);
    return verdict;
}

api.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.url || changeInfo.status === 'loading') {
        refreshTab(tabId, changeInfo.url ?? tab.url ?? '').catch(() => {});
    }
});

api.runtime.onMessage.addListener((message, sender, sendResponse) => {
    const handle = async () => {
        switch (message.type) {
            case 'page-verdict':
                return refreshTab(sender.tab.id, sender.tab.url, { hasSensitiveForm: message.hasSensitiveForm });
            case 'tab-verdict': {
                const tab = await api.tabs.get(message.tabId);
                return refreshTab(tab.id, tab.url ?? '', { hasSensitiveForm: true });
            }
            case 'trust-domain': {
                const trustedDomains = await getTrustedDomains();
                await api.storage.local.set({ trustedDomains: [...new Set([...trustedDomains, message.domain])] });
                break;
            }
            case 'untrust-domain': {
                const trustedDomains = await getTrustedDomains();
                await api.storage.local.set({ trustedDomains: trustedDomains.filter((domain) => domain !== message.domain) });
                break;
            }
            case 'leave-page':
                await api.tabs.update(sender.tab.id, { url: 'about:blank' });
                return null;
            default:
                return null;
        }
        const tabId = message.tabId ?? sender.tab?.id;
        if (tabId !== undefined) {
            const tab = await api.tabs.get(tabId);
            return refreshTab(tabId, tab.url ?? '');
        }
        return null;
    };

    handle().then(sendResponse, () => sendResponse(null));
    return true;
});
