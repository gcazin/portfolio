(() => {
    const api = globalThis.browser ?? globalThis.chrome;
    const DISMISS_KEY = 'against-phishing-dismissed';
    const MODAL_ID = 'against-phishing-modal';
    const SENSITIVE_NAME = /pass|mot.?de.?passe|card|carte|cvv|cvc|crypto|iban|expir|(^|[_\-\s])cb($|[_\-\s])/i;

    let sensitiveLookupDone = false;
    let currentVerdict = null;

    function isSensitiveField(element) {
        if (!(element instanceof HTMLInputElement)) {
            return false;
        }
        if (element.type === 'password' || (element.autocomplete ?? '').startsWith('cc-')) {
            return true;
        }
        const hints = [element.name, element.id, element.placeholder, element.getAttribute('aria-label')].join(' ');
        return SENSITIVE_NAME.test(hints);
    }

    function pageHasSensitiveForm() {
        return [...document.querySelectorAll('input')].some(isSensitiveField);
    }

    function isDismissed() {
        try {
            return sessionStorage.getItem(DISMISS_KEY) === location.hostname;
        } catch {
            return false;
        }
    }

    function dismiss() {
        try {
            sessionStorage.setItem(DISMISS_KEY, location.hostname);
        } catch {
            // Storage blocked: the warning simply comes back on the next trigger.
        }
    }

    let restorePage = null;

    function removeModal() {
        document.getElementById(MODAL_ID)?.remove();
        restorePage?.();
        restorePage = null;
    }

    /**
     * Freezes the page behind the modal: no scroll, no clicks, no keystrokes into the form.
     */
    function lockPage() {
        const root = document.documentElement;
        const previousOverflow = root.style.overflow;
        const previousInert = document.body?.inert ?? false;
        document.activeElement?.blur?.();
        root.style.overflow = 'hidden';
        if (document.body) {
            document.body.inert = true;
        }
        return () => {
            root.style.overflow = previousOverflow;
            if (document.body) {
                document.body.inert = previousInert;
            }
        };
    }

    function showModal(verdict, trigger) {
        if (isDismissed() || document.getElementById(MODAL_ID)) {
            return;
        }
        const isDanger = verdict.level === 'danger';
        const accent = isDanger ? '#b91c1c' : '#c2410c';
        const host = document.createElement('div');
        host.id = MODAL_ID;
        const shadow = host.attachShadow({ mode: 'closed' });

        const title = isDanger ? 'FAUX SITE PROBABLE' : 'SITE SUSPECT';
        const subtitle = isDanger
            ? (verdict.brand ? `Ce site imite ${verdict.brand}. Ne saisissez RIEN.` : 'Ce site présente de forts signes d\'arnaque. Ne saisissez RIEN.')
            : 'Ce site présente des signes suspects. Ne saisissez rien sans être certain.';
        const lead = trigger === 'input'
            ? 'Vous alliez taper un mot de passe ou des informations bancaires.'
            : 'Vous êtes sur :';

        shadow.innerHTML = `
            <style>
                :host { all: initial; }
                .overlay { position: fixed; inset: 0; z-index: 2147483647; display: flex;
                    padding: 16px; box-sizing: border-box; overflow-y: auto; background: ${accent}; color: #fff;
                    font: 17px/1.5 system-ui, -apple-system, "Segoe UI", sans-serif; animation: in .15s ease-out; }
                @keyframes in { from { opacity: 0; } }
                .panel { width: 100%; max-width: 720px; margin: auto; text-align: center; }
                .icon { font-size: 88px; line-height: 1; margin-bottom: 8px; }
                h1 { margin: 0; font-size: clamp(34px, 7vw, 64px); font-weight: 900; letter-spacing: .02em; line-height: 1.05; }
                .subtitle { margin: 14px 0 24px; font-size: clamp(19px, 3vw, 26px); font-weight: 700; }
                .lead { margin: 0; opacity: .9; }
                .host { display: inline-block; margin: 8px 0 22px; padding: 8px 16px; border-radius: 10px; background: rgba(0,0,0,.28);
                    font: 700 clamp(17px, 3vw, 24px)/1.3 ui-monospace, Menlo, Consolas, monospace; word-break: break-all; }
                ul { text-align: left; margin: 0 auto 22px; padding: 16px 20px 16px 38px; max-width: 600px; border-radius: 12px; background: rgba(0,0,0,.2); }
                li { margin: 4px 0; }
                .advice { margin: 0 0 26px; font-weight: 600; }
                .leave { display: block; width: 100%; max-width: 480px; margin: 0 auto 28px; padding: 18px 24px; border: 0; border-radius: 14px;
                    background: #fff; color: ${accent}; font-family: inherit; font-size: 22px; font-weight: 800; line-height: 1.2; cursor: pointer; box-shadow: 0 10px 30px rgba(0,0,0,.25); }
                .leave:focus-visible { outline: 4px solid #fde68a; outline-offset: 3px; }
                details { font-size: 14px; opacity: .85; }
                summary { cursor: pointer; text-decoration: underline; }
                .risk { margin-top: 12px; display: grid; gap: 10px; justify-items: center; }
                label { display: flex; gap: 8px; align-items: flex-start; text-align: left; max-width: 480px; }
                .secondary { font: inherit; padding: 8px 14px; border-radius: 8px; border: 1px solid rgba(255,255,255,.7); background: transparent; color: #fff; cursor: pointer; }
                .secondary:disabled { opacity: .45; cursor: not-allowed; }
            </style>
            <div class="overlay" role="alertdialog" aria-modal="true" aria-labelledby="ap-title" aria-describedby="ap-subtitle">
                <div class="panel">
                    <div class="icon" aria-hidden="true">⚠️</div>
                    <h1 id="ap-title"></h1>
                    <p id="ap-subtitle" class="subtitle"></p>
                    <p class="lead"></p>
                    <div class="host"></div>
                    <ul></ul>
                    <p class="advice">Pour accéder au vrai service, tapez vous-même son adresse officielle. Ne suivez jamais un lien reçu par SMS ou e-mail.</p>
                    <button class="leave" data-action="leave">Quitter ce site (recommandé)</button>
                    <details>
                        <summary>Je sais ce que je fais</summary>
                        <div class="risk">
                            <label><input type="checkbox" data-action="acknowledge"> Je comprends que je risque de me faire voler mes identifiants ou mon argent.</label>
                            <button class="secondary" data-action="dismiss" disabled>Continuer pour cette visite</button>
                            <button class="secondary" data-action="trust" disabled>Toujours faire confiance à ${verdict.domain ? 'ce domaine' : 'ce site'}</button>
                        </div>
                    </details>
                </div>
            </div>`;

        shadow.getElementById('ap-title').textContent = title;
        shadow.getElementById('ap-subtitle').textContent = subtitle;
        shadow.querySelector('.lead').textContent = lead;
        shadow.querySelector('.host').textContent = verdict.hostname;
        const list = shadow.querySelector('ul');
        for (const reason of verdict.reasons.slice(0, 4)) {
            const item = document.createElement('li');
            item.textContent = reason.message;
            list.append(item);
        }

        const riskyButtons = shadow.querySelectorAll('[data-action="dismiss"], [data-action="trust"]');
        shadow.querySelector('[data-action="acknowledge"]').addEventListener('change', (event) => {
            riskyButtons.forEach((button) => {
                button.disabled = !event.target.checked;
            });
        });
        shadow.querySelector('[data-action="leave"]').addEventListener('click', () => {
            api.runtime.sendMessage({ type: 'leave-page' });
        });
        shadow.querySelector('[data-action="dismiss"]').addEventListener('click', () => {
            dismiss();
            removeModal();
        });
        shadow.querySelector('[data-action="trust"]').addEventListener('click', async () => {
            await api.runtime.sendMessage({ type: 'trust-domain', domain: verdict.domain });
            removeModal();
        });

        restorePage = lockPage();
        document.documentElement.append(host);
        shadow.querySelector('[data-action="leave"]').focus();
    }

    async function requestVerdict(hasSensitiveForm) {
        try {
            return await api.runtime.sendMessage({ type: 'page-verdict', hasSensitiveForm });
        } catch {
            return null;
        }
    }

    async function onSensitiveFocus() {
        if (!sensitiveLookupDone) {
            sensitiveLookupDone = true;
            currentVerdict = (await requestVerdict(true)) ?? currentVerdict;
        }
        if (currentVerdict && ['warning', 'danger'].includes(currentVerdict.level)) {
            showModal(currentVerdict, 'input');
        }
    }

    async function init() {
        const hasSensitiveForm = pageHasSensitiveForm();
        sensitiveLookupDone = hasSensitiveForm;
        currentVerdict = await requestVerdict(hasSensitiveForm);
        if (currentVerdict?.level === 'danger') {
            showModal(currentVerdict, 'load');
        }
        document.addEventListener('focusin', (event) => {
            if (isSensitiveField(event.target)) {
                onSensitiveFocus();
            }
        }, true);
    }

    init();
})();
